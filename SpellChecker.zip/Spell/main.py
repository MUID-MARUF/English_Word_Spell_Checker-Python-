
import os
import itertools

lower_alpha = 'abcdefghijklmnopqrstuvwxyz'

def incorrect_arrangement(input_word):
    found = False
    try:
        with open('words.txt', 'r') as words:
            for line in words:
                word = line.strip()
                if len(word) == len(input_word) and sorted(word) == sorted(input_word):
                    found = True
                    print(word)
                    break
    except IOError:
        print("\nUnexpected error occurred.......\n")
    return found


def exchanged_characters(input_word):
    found = False
    try:
        with open('words.txt', 'r') as words:
            for line in words:
                word = line.strip()
                if len(word) == len(input_word):
                    for i in range(len(input_word)):
                        for char in lower_alpha:
                            temp_word = list(input_word)
                            temp_word[i] = char
                            if ''.join(temp_word) == word:
                                found = True
                                print(word)
                                break
                        if found:
                            break
    except IOError:
        print("\nUnexpected error occurred\n")
    return found


def missing_character(input_word):
    found = False
    try:
        with open('words.txt', 'r') as words:
            for line in words:
                word = line.strip()
                for char in lower_alpha:
                    temp_word = input_word + char
                    if sorted(temp_word) == sorted(word):
                        found = True
                        print(word)
                        break
                if found:
                    break
    except IOError:
        print("\nUnexpected error occurred\n")
    return found


def extra_character(input_word):
    found = False
    try:
        with open('words.txt', 'r') as words:
            for line in words:
                word = line.strip()
                if len(word) == len(input_word) - 1:
                    for i in range(len(input_word)):
                        temp_word = input_word[:i] + input_word[i + 1:]
                        if temp_word == word:
                            found = True
                            print(word)
                            break
                if found:
                    break
    except IOError:
        print("\nUnexpected error occurred\n")
    return found


def mixed_extra_missing(input_word):
    found = False
    try:
        with open('words.txt', 'r') as words:
            for line in words:
                word = line.strip()
                if len(word) == len(input_word):
                    for i in range(len(input_word)):
                        for char in lower_alpha:
                            temp_word = input_word[:i] + char + input_word[i + 1:]
                            if sorted(temp_word) == sorted(word):
                                found = True
                                print(word)
                                break
                        if found:
                            break
                if found:
                    break
    except IOError:
        print("\nUnexpected error occurred\n")
    return found


def main():
    while True:
        input_word = input("Enter the word: ").strip().lower()
        correct = False

        try:
            with open('words.txt', 'r') as words:
                for line in words:
                    if input_word == line.strip().lower():
                        correct = True
                        break
        except IOError:
            print("Not able to open words.txt")
            continue

        if correct:
            print("\nSpelling is correct\n")
        else:
            print("\nSpelling is wrong. Possible right spellings are given below:- \n\n")
            if not any([missing_character(input_word), extra_character(input_word),
                        mixed_extra_missing(input_word), incorrect_arrangement(input_word),
                        exchanged_characters(input_word)]):
                print("\nNo such word exist\n")

        input("\nPress any key to continue...\n\n")


if __name__ == "__main__":
    main()
